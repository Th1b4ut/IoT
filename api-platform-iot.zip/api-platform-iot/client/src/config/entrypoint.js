export const ENTRYPOINT = process.env.REACT_APP_API_ENTRYPOINT;
