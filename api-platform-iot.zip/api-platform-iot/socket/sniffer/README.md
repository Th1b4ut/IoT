

https://www.zigbee2mqtt.io/how_tos/how_to_sniff_zigbee_traffic.html

    whsniff -c 11 |wireshark -k -i -
